package za.ac.cput.domain;

public class Entity
{

}
